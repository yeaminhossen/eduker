<?php
/**
 * @package TutorLMS/Templates
 * @version 1.4.3
 */
?>

<div class="course__content-2">